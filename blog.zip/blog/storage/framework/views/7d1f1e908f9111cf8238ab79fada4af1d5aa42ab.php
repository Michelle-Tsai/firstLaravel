<?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<a href="/article/<?php echo e($article->id); ?>">
    <img src="<?php echo e($article->image); ?>" alt="" style="..."/>
</a>

<br>
Title:<?php echo e($article->title); ?><br>
Content:<?php echo e($article->content); ?><br>
<br><br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>