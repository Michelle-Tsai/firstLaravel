<!doctype html>
<html>
  <head>
      <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </head>
  <body>
    <img src="<?php echo e($article->image); ?>" alt="" style="..."/>
    <img src="<?php echo e(asset('img/test.png')); ?>" alt=""/>

    <br>
    Title:<?php echo e($article->title); ?><br>
    Content:<?php echo e($article->content); ?><br>
    <br><br>

    <a class="btn btn-primary" href="/">Back</a>
  </body>
</html>