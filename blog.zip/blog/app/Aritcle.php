<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Aritcle extends Model
{
    //
}
