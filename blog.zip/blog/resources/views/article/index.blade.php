@foreach($articles as $article)
<a href="/article/{{$article->id}}">
    <img src="{{$article->image}}" alt="" style="..."/>
</a>

<br>
Title:{{$article->title}}<br>
Content:{{$article->content}}<br>
<br><br>
@endforeach