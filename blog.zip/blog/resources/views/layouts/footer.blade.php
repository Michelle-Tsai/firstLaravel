<footer class="page-footer font-small fixed-bottom bg-secondary">

    <!-- Copyright -->
    <div class="footer-copyright text-center py-3">© 2019 Copyright: Michelle
        <a href="/" class="text-white"> </a>
    </div>
    <!-- Copyright -->

</footer>